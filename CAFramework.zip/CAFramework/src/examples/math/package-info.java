/**
 * 
 */
/**
 * @author Derichs
 *
 */
package examples.math;